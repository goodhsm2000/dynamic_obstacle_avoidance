# custom_msgs

A ROS package for custom ROS messages generation.